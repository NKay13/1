package Classes;

public class Magazin {

	private static Raioane [] nr_raioane;
	
	private static Caserie [] nr_caserii;
	
	private static Inventar inv;
	
	
	
}
