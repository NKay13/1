package Classes;

import java.util.*;

public class Caserie {

	private Queue<Client> coada = new LinkedList<Client>();
	
	private Angajat operator_casa; //clasa Angajat va implementa interfata Cont
	
	private Cos_produse [] istoric; // cos_produse va implementa o interfata de tip achizitii
	
	private Bani bani_casa;
	
	public Caserie() {
	}
	
	public void setCasier(Angajat f) {
		this.operator_casa = f;
	}
	
	public void addClient (Client c) {	
		this.coada.add(c);
	}
	
	public void checkOut() {
		Client toCheckout = this.coada.remove();
		
		//TODO: extras achizitia si trecuta in istoric, impreuna cu primirea banilor
	
}
