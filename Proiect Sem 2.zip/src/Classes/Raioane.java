package Classes;

public class Raioane {
	
	private String denumire_raion;
	
	private Categ_prod [] rafturi;
	
	public Raioane (String categ, int nr_rafturi) {
		// TODO corpul constructorului
	}
	
	
}
